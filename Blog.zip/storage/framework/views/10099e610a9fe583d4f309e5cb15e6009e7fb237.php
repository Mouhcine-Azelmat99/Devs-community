

<?php $__env->startSection('title'); ?>
    Admin Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav class="bg-light shadow p-4" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item fs-4"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active fs-4" aria-current="page">Posts</li>
            </ol>
          </nav>
        <div class="row py-5">
            <script>
                <?php if(Session::has('msg')): ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true,
                    "timeOut": "10000",
                    "extendedTimeOut": "5000",

                }
                toastr.success("<?php echo e(Session::get('msg')); ?>");
                <?php endif; ?>
            </script>
        <div class="mt-5">
                <h3>posts publied</h3>
        
             <table class="table table-striped table-bordered shadow">
                <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Status</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if(!($user->isAdmin)): ?>
                            <form action="<?php echo e(route('admin.setAdmin',$user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button class="btn btn-danger bg-danger" type="submit">Set Admin</button>
                            </form>
                        <?php else: ?>
                            <span class="bg-success p-2 text-white px-4">Admin</span>
                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                </tbody>
        </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/admin/users.blade.php ENDPATH**/ ?>