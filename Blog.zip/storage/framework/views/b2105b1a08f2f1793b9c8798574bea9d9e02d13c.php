<?php $__env->startSection('title'); ?>
Devs community <?php echo e($slug); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="main" class="<?php if($dark_theme): ?> main-dark <?php endif; ?>">
    <div class="container">
        <Show :user_id='<?php echo json_encode($user_id, 15, 512) ?>' :slug='<?php echo json_encode($slug, 15, 512) ?>' :langue='<?php echo json_encode($langue, 15, 512) ?>'></Show>
    </div>
</section>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/posts/showPost.blade.php ENDPATH**/ ?>