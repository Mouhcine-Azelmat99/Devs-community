<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/x-icon" href="images/devs-logo.png">
    <!-- bootsrap style  -->
    
    <!-- font awesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- style css  -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

</head>
<body  <?php if($langue=='ar'): ?>
    class="arab"
<?php endif; ?>>
    <div class="loader">
        <img src="<?php echo e(asset('images/Pulse-1s-200px.svg')); ?>" alt="loader">
    </div>
    <?php if(auth()->guard()->check()): ?> <?php else: ?>
        <div class="login_modal">
            <section class="login">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                        <ul class="header">
                                <li id="list_login" class="active">
                                    <button id="login_show">Login</button>
                                </li>
                                <li id="list_register">
                                    <button id="register_show">Register</button>
                                </li>
                            </ul>
                            <hr>
                            <form method="POST" id="login_form" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <label for="email" class="form-label">email</label>
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="my-2">
                                    <label for="password" class="form-label">password</label>
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <a href="register">I don't have account</a>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn py-2">Confirme</button>
                                </div>
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('facebook.login')); ?>" style="background:#1877F2;color:#fff" class="btn btn-facebook py-2 btn-user btn-block">
                                        <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                    </a>
                                </div>
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('google.login')); ?>" style="background:#DB4437;color:#fff" class="btn btn-google py-2 btn-user btn-block">
                                        <i class="fab fa-google fa-fw"></i> Login with Google
                                    </a>
                                </div>
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </form>

                            
                            <form method="POST" id="register_form" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                                <div class="my-2">
                                    <label for="username" class="form-label">username</label>
                                    <input id="username" type="text" class="form-control px-4 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="my-2">
                                    <label for="email" class="form-label">email</label>
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="my-2">
                                    <label for="password" class="form-label">password</label>
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="my-2">
                                    <label for="password-confirm" class="form-label">Confirm password-confirm</label>
                                    <input id="password-confirm" type="password" class="form-control <?php $__errorArgs = ['password-confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password-confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <a href="login">I have already account</a>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-lg">Confirme</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </section>
        </div>
    <?php endif; ?>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <div id="theme" class="<?php if($dark_theme): ?> theme-dark <?php endif; ?>">
    <form action="<?php echo e(route('theme')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($dark_theme); ?>" name="theme">
            <button>
            <?php if($dark_theme): ?>
                <img src="/images/brightness.png" alt="">
            <?php else: ?>
                <i class="fas fa-moon"></i>
            <?php endif; ?>
        </button>
        </form>
    </div>
    <div id="gotop" class="<?php if($dark_theme): ?> gotop-dark <?php endif; ?>">
        <button onclick="topFunction()">
            <i class="fas fa-angle-double-up"></i>
        </button>
    </div>

    <script>
    function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    }
    $(function(){
        setTimeout(() => {
            $(".loader").fadeOut(400)
        }, 500);
    })
    $(function(){
        setTimeout(() => {
            $(".login_modal").fadeIn(1000)
        }, 20000);
    })

    var prevScrollpos = window.pageYOffset;
        window.onscroll = function() {
        var currentScrollPos = window.pageYOffset;
        if (prevScrollpos > currentScrollPos) {
            document.getElementById("header").style.top = "0";
        } else {
            if (window.matchMedia('screen and (max-width: 768px)').matches) {
                document.getElementById("header").style.top = "-225px";
            }else{
                document.getElementById("header").style.top = "-165px";
            }
        }
        prevScrollpos = currentScrollPos;
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <script src="<?php echo e(mix('js/main.js')); ?>"></script>
    

</body>
</html>
<?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/layouts/app.blade.php ENDPATH**/ ?>