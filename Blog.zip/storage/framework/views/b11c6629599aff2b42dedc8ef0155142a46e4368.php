<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 my-3">
                <div class="bg-light shadow p-5">
                    <h2 class="text-center">Posts publied</h2>
                    <h1 class="text-center">
                        <?php echo e($data['postcount']); ?>

                    </h1>
                </div>
            </div>
            <div class="col-lg-3 my-3">
                <div class="bg-light shadow p-5">
                    <h2 class="text-center">Ressources</h2>
                    <h1 class="text-center">
                       <?php echo e($data['ressourcecount']); ?>

                    </h1>
                </div>
            </div>
            <div class="col-lg-3 my-3">
                <div class="bg-light shadow p-5">
                    <h2 class="text-center">Questions</h2>
                    <h1 class="text-center">
                       <?php echo e($data['questioncount']); ?>

                    </h1>
                </div>
            </div>
            <div class="col-lg-3 my-3">
                <div class="bg-light shadow p-5">
                    <h2 class="text-center">Users</h2>
                    <h1 class="text-center">
                        <?php echo e($data['usercount']); ?>

                    </h1>
                </div>
            </div>
        </div>
        <div class="row py-5">
        <div class="mt-5">
            <h3 class="p-3 shadow">Latest posts publied</h3>
            <table class="table table-striped table-bordered shadow my-5">
                <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Title</th>
                    <th scope="col">Content</th>
                    <th scope="col">Image</th>
                    <th scope="col">Publied By</th>
                    <th scope="col">Publied at</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->content); ?></td>
                    <td><img src="/images/<?php echo e($post->img); ?>" height="70px" width="80px"></td>
                    <td><?php echo e($post->category->name ?? null); ?></td>
                    <td><?php echo e($post->tag); ?></td>
                    <td><?php echo e($post->user->username); ?></td>
                    <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                    <td>
                        <div class="p-2">
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete_modal_<?php echo e($post->id); ?>"><i class="fas fa-trash-alt"></i></button>
                        </div >
                        
                        <div id="delete_modal_<?php echo e($post->id); ?>" class="modal fade" aria-labelledby="delete_modal_<?php echo e($post->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-confirm">
                                <div class="modal-content">
                                    <div class="modal-header flex-column">
                                        <h4 class="modal-title w-100">Are you sure?</h4>
                                    </div>
                                    <div class="modal-body">
                                        <p>Do you really want to delete these records? This process cannot be undone.</p>
                                    </div>
                                    <div class="modal-footer justify-content-center">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <form action="<?php echo e(route('admin.posts.destroy',$post->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>