<div class="col-lg-3" id="sidebar">
    
    <div class="addPost">
        <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <form action="<?php echo e(route('post.addPost')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text"name="title" class="form-control" placeholder="Titre *" required>
        <textarea name="content" placeholder="Content ..." id="body" class="form-control"></textarea>
        <div class="mb-3">
            <select class="form-select" name="category_id" aria-label="Default select example">
                <option value="0">Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option  value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <input type="text" name="tag" class="form-control" placeholder="#">
        <input type="file" name="img" class="form-control" placeholder="Upload image">
        <div class="d-grid gap-2">
            <button type="submit" class="btn ">Ajouter</button>
        </div>
    </form>
    </div>
    <div class="categories">
        <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="#"><?php echo e($category->name); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/sideBar.blade.php ENDPATH**/ ?>