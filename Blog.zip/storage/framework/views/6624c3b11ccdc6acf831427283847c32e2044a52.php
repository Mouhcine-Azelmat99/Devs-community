<?php $__env->startSection('title'); ?>
  Saved posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="saved" class="<?php if(session('isDark')): ?> main-dark <?php endif; ?>">
    <div class="container">
        <Saved :user_id='<?php echo json_encode($user_id, 15, 512) ?>'></Saved>
    </div>
</section>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/posts/saved.blade.php ENDPATH**/ ?>