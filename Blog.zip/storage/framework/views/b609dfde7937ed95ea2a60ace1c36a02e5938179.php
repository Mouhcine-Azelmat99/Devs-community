<header id="header">
    <nav id="nav-up">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                </div>
                <div class="col-lg-4"></div>
                <Search :langue='<?php echo json_encode($langue, 15, 512) ?>'></Search>
            </div>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg" id="navbar">
        <div class="container">
          <a class="navbar-brand" href="/">
          <img src="/images/devs-logo.png">
          </a>
          <button class="navbar-toggler" id="show" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
          </button>
          <button class="navbar-toggler" id="hide" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-times"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav" id="menu">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">
                    <?php if($langue=='ar'): ?>
                        المنشورات
                    <?php else: ?>
                        Posts
                    <?php endif; ?>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('ressources.index')); ?>">
                     <?php if($langue=='ar'): ?>
                    المصادر
                    <?php else: ?>
                        Ressources
                    <?php endif; ?>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('questions.index')); ?>">
                     <?php if($langue=='ar'): ?>
                        الاسئلة
                    <?php else: ?>
                        questions
                    <?php endif; ?>
                </a>
              </li>
            </ul>
            <ul <?php if($langue=='ar'): ?>
                    class="navbar-nav me-auto"
                <?php else: ?>
                    class="navbar-nav ms-auto"
                <?php endif; ?> id="social-media">
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item mx-2 mb-2">
                    <a class="nav-link" href="/profile" id="login"><?php echo e(Auth::user()->username); ?></a>
                </li>
                <li class="nav-item mx-auto">
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <button class="nav-link" id="login">
                             <?php if($langue=='ar'): ?>
                                تسجيل الخروج
                            <?php else: ?>
                                Logout
                            <?php endif; ?>
                        </button>
                    </form>
                </li>
                <?php else: ?>
                <li class="nav-item mx-3">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>" id="login">
                    <?php if($langue=='ar'): ?>
                        تسجيل الدخول
                    <?php else: ?>
                        Login / Register
                    <?php endif; ?>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item mx-auto">
                    <div class="dropdown">
                        <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                             <?php if($langue=='ar'): ?>
                                اللغة
                            <?php else: ?>
                                Langue
                            <?php endif; ?>
                        </button>
                        <ul class="dropdown-menu">
                            <li>
                                <form action="<?php echo e(route('langue')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                    <input type="hidden" name="langue" value="ar">
                                    <button class="nav-link" id="login">العربية</button>
                                </form>
                            </li>
                            <li>
                                <form action="<?php echo e(route('langue')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                    <input type="hidden" name="langue" value="an">
                                    <button class="nav-link" id="login">Anglish</button>
                                </form>
                            </li>
                        </ul>
                      </div>
                </li>
            </ul>
          </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>