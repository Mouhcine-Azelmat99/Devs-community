<div class="footer-dark">
    <footer>
        <div class="container">
            <div class="row">
            <div class="col-md-6 item text">
                    <h3>Devs Community</h3>
                    <?php if($langue == 'ar'): ?>
                        <p>منصة لتبادل المعلومات والأفكار حول علوم الكمبيوتر أيضًا لطرح أسئلة للإجابة عليها من قبل أشخاص آخرين ، أيضًا من خلال هذه المنصة يمكنك العثور على أو وضع مصادر للتعلم ومساعدة الناس الآخرين.</p>
                    <?php else: ?>
                        <p>Platform for sharing information and thoughts about computer science domain also for putting up questions for answer it by other poeple, also by this Platform you can find or put a ressources to learning and help other poeple.</p>
                    <?php endif; ?>
                </div>
                
                <div class="col-sm-6 col-md-3 link">
                <?php if($langue == 'ar'): ?>
                    <h3>الصفحات</h3>
                    <ul>
                        <li><a href="#">المنشورات</a></li>
                        <li><a href="#">الاسئلة</a></li>
                        <li><a href="#">المصادر</a></li>
                    </ul>
                <?php else: ?>
                    <h3>Pages</h3>
                    <ul>
                        <li><a href="#">posts</a></li>
                        <li><a href="#">questions</a></li>
                        <li><a href="#">ressources</a></li>
                    </ul>
                <?php endif; ?>
                </div>
                <div class="col-sm-6 col-md-3 contact">
                <?php if($langue == 'ar'): ?>
                    <h3>راسلنا</h3>
                <?php else: ?>
                    <h3>Contact us</h3>
                <?php endif; ?>
                <form>
                    <input type="text" class="form-control" <?php if($langue == 'ar'): ?>
                        placeholder="رسالتك"
                    <?php else: ?>
                        placeholder="Your message"
                    <?php endif; ?> />
                    <button class="btn" type="submit">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
                </div>
                
            </div>
            <p class="copyright">Devs Community © 2022</p>
            <p class="copyright">
                 <?php if($langue == 'ar'): ?>
                    من تطوير محسن ازلماط
                <?php else: ?>
                    Developed by Mouhcine azelmat
                <?php endif; ?>
            </p>
        </div>
    </footer>
</div><?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>