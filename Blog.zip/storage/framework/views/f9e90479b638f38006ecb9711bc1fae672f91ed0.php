<div class="col-lg-4" id="sidebar">
    <div class="addPost">
        <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <form action="<?php echo e(route('questions.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text"name="title" class="form-control" placeholder="Titre *" required>
        <textarea name="body" placeholder="Content ..." id="body" class="form-control"></textarea>
        <input type="file" name="image" class="form-control" placeholder="Upload image">
        <div class="d-grid gap-2">
            <button type="submit" class="btn ">Ajouter</button>
        </div>
    </form>
    </div>
</div>
<?php /**PATH C:\Users\HP 840\Desktop\laravel\Blog\resources\views/sidebar/addQuestion.blade.php ENDPATH**/ ?>